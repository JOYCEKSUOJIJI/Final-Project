const jwt = require ('jsonwebtoken');
const AWS = require('aws-sdk');
const dbClient = new AWS.DynamoDB.DocumentClient();
// const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySWQiOiJhZG1pbjFAdGVzdC5jb20iLCJJc0FkbWluIjp0cnVlLCJpYXQiOjE2MjkyNjI2Njl9.PYqKFrQxmMO1yY31smKEd71_RyrXUnjj0r3LpHNZ2aU';
// const res = jwt.verify(token, 'JingPersonalProject');
//     if (res && res.UserId && res.IsAdmin && res.iat && res.IsAdmin) {
//         console.log(res);
//     };
exports.handler =  function(event, context, callback) {
    const token = event.authorizationToken;
    const res = jwt.verify(token, 'JingPersonalProject');
    if (res && res.UserId && res.IsAdmin && res.iat) {
        const oldItem = await dbClient.get({TableName: 'adminTable', Key: {"UserId": res.UserId}}).promise();
        if (!oldItem || !oldItem.Item || !oldItem.Item.UserId) {
            callback("User has been deleted", generatePolicy('user', 'Deny', event.methodArn));
        }
        // else if (!res.IsAdmin) {
        //     callback("Not admin!", generatePolicy('user', 'Deny', event.methodArn))
        // }
        else {
            callback(null, generatePolicy('user', 'Allow', event.methodArn));
        }
    }
    else {
        callback("Error: Invalid token")
    }
};

// Help function to generate an IAM policy
var generatePolicy = function(principalId, effect, resource) {
    var authResponse = {};
    
    authResponse.principalId = principalId;
    if (effect && resource) {
        var policyDocument = {};
        policyDocument.Version = '2012-10-17'; 
        policyDocument.Statement = [];
        var statementOne = {};
        statementOne.Action = 'execute-api:Invoke'; 
        statementOne.Effect = effect;
        statementOne.Resource = resource;
        policyDocument.Statement[0] = statementOne;
        authResponse.policyDocument = policyDocument;
    }
    
    // Optional output with custom properties of the String, Number or Boolean type.
    authResponse.context = {
        "stringKey": "stringval",
        "numberKey": 123,
        "booleanKey": true
    };
    return authResponse;
}